DataViewer - ESP32 Data Viewer
================================

Installation:
1. Drag DataViewer.app to your Applications folder
2. Double-click to run

Requirements:
- macOS 13.0 or later
- Network access to ESP32 device

Usage:
1. Enter ESP32 IP address and port (e.g., 192.168.1.183:1234)
2. Click "Connect" to establish connection
3. Use menu commands to interact with device

Features:
- Real-time packet monitoring
- Data logging with annotations
- Multiple filter presets
- Packet decoding and analysis

For support, visit: https://github.com/Ylianst/ESP-IQ2020
